<?php

/**
 * @file
 * Post update functions for Contextual Links.
 */

/**
 * Ensure new page loads use the updated JS and get the updated markup.
 */
function contextual_post_update_fixed_endpoint_and_markup() {
  // Empty update to trigger a change to css_js_query_string and invalidate
  // cached markup.
}
